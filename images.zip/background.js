browser.alarms.onAlarm.addListener(function(alarm) {
    browser.notifications.create({
      "type": "basic",
      // "icons": {
      //   "48": "reminder.png"
      // },
      "title": "Reminder",
      "message": alarm.name
    });
  });

// browser.notifications.onClicked.addListener(function(notificationId) {
// browser.tabs.create({
//     url: `popup/popup.html?reminder=${notificationId}`
// });
// });