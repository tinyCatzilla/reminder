// // Get all reminders
// browser.storage.local.get().then(reminders => {
//     // Display the reminders
//     for (let name in reminders) {
//       const reminder = reminders[name];
//       const p = document.createElement('p');
//       p.textContent = `Reminder: ${name} at ${reminder.dueAt}`;
//       document.body.appendChild(p);
//     }
//   });
  
// const params = new URLSearchParams(window.location.search);
// const reminderName = params.get('reminder');

// if (reminderName) {
//     // This popup was opened by clicking a notification, so display options for the reminder
//     const options = document.createElement('div');
//     options.innerHTML = `
//         <h2>${reminderName}</h2>
//         <button id="delete">Delete</button>
//         <button id="delay">Delay</button>
//         <button id="keep">Keep</button>
//     `;
//     document.body.appendChild(options);

//     document.querySelector("#delete").addEventListener('click', function() {
//         // Delete the reminder
//         browser.alarms.clear(reminderName);
//         browser.storage.local.remove(reminderName);
//     });

//     document.querySelector("#delay").addEventListener('click', function() {
//         // Display a UI for delaying the reminder
//     });

//     document.querySelector("#keep").addEventListener('click', function() {
//         // Do nothing
//     });
// }
document.addEventListener('DOMContentLoaded', function() {
    document.querySelector("#reminder-form").addEventListener('submit', function(event) {
        event.preventDefault();
        const name = document.querySelector("#reminder-name-input").value;
        const time = document.querySelector("#reminder-time-input").value;
    
        // Create the reminder
        if (time) {
        browser.alarms.create(name, {
            delayInMinutes: parseTime(time)
        });
        }
    
        // Save the reminder
        // browser.storage.local.set({
        // [name]: {
        //     time: time,
        //     dueAt: time ? new Date(Date.now() + parseTime(time) * 60000).toISOString() : null
        // }
        // });

        // Create a new reminder div
        const reminderDiv = document.createElement('div');
        reminderDiv.className = 'reminder';
    
        // Create a new h2 for the reminder name and add it to the div
        const reminderName = document.createElement('h2');
        reminderName.textContent = name;
        reminderDiv.appendChild(reminderName);
    
        // Create a new h1 for the reminder time and add it to the div
        const reminderTime = document.createElement('h1');
        reminderTime.textContent = time;
        reminderDiv.appendChild(reminderTime);
    
        // Add the new reminder div to the reminder container
        document.querySelector('#reminder-container').appendChild(reminderDiv);

    });
});

function parseTime(time) {
const match = time.match(/(\d+)([smhdy]|$)/g);
if (!match) {
    // Assume this is an exact time and calculate how many minutes until that time.
    if(time.length !== 4) { return; }
    const now = new Date();
    const exactTime = new Date(now.toDateString() + ' ' + time);
    if (isNaN(exactTime)) {
    throw new Error('Invalid exact time: ' + time);
    }
    const diff = exactTime - now;
    return diff > 0 ? diff / 60000 : (diff + 24 * 60 * 60 * 1000) / 60000;
}

const units = {
    s: 1 / 60,
    m: 1,
    h: 60,
    d: 60 * 24,
    y: 60 * 24 * 365
};

let total = 0;
for (let part of match) {
    const unit = part.slice(-1);
    const value = parseFloat(part.slice(0, -1));
    if (isNaN(value) || !units[unit]) {
    throw new Error('Invalid time part: ' + part);
    }
    total += value * units[unit];
}

return total;
}
  

  